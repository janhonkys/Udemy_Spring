package org.hibernate.validator.referenceguide.chapter06;

public enum CaseMode {
	UPPER,
	LOWER;
}
