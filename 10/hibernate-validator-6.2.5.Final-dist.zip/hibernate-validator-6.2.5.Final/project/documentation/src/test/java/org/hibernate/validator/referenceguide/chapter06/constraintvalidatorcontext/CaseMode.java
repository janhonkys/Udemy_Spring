package org.hibernate.validator.referenceguide.chapter06.constraintvalidatorcontext;

public enum CaseMode {
	UPPER,
	LOWER;
}
