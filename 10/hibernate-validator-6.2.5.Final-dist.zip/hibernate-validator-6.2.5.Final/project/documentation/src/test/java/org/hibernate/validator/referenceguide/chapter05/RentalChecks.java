package org.hibernate.validator.referenceguide.chapter05;

public interface RentalChecks {
}
