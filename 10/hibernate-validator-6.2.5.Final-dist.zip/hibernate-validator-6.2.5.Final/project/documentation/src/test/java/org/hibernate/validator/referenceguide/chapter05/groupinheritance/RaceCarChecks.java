package org.hibernate.validator.referenceguide.chapter05.groupinheritance;

import javax.validation.groups.Default;

public interface RaceCarChecks extends Default {
}
